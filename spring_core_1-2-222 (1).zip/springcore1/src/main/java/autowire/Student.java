package autowire;

public class Student {
 Marks objM;
  Student()
  {
	  System.out.println("Student class Cons");
  }
	public Marks getObjM() {
		return objM;
	}
	public void setObjM(Marks objM) {
		this.objM = objM;
	}
	void showDetail()
	{
		System.out.println("Show detail of student");
		objM.show();
	}
}
