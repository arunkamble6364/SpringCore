package autowire;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestAutowire {
	public static void main(String s[])
	{
		 ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationcontext.xml");	 
		 Student obj= (Student) context.getBean("sm");
		 obj.showDetail();
	}
}
