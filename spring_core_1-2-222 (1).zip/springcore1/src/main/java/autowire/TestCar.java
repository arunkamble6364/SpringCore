package autowire;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestCar {
	public static void main(String s[])
	{
		 ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationcontext.xml");	 
		 Car obj= (Car) context.getBean("carobj");
		 obj.show();
	}
}
// we are having more than one constructor say first cons with 0 argument
/*2 with two and 3rd with 3 arugment so in case of autowire mode constructor 3rd constructor is called which is having largest no of parameter list */