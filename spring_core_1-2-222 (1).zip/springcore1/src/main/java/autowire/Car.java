package autowire;

public class Car {
EngineType etobj ;

	public Car(EngineType etobj) {
		super();
		this.etobj = etobj;
	}
	public void show()
	{
		System.out.println("Car has engine type");
		etobj.showEngine();
	}

}
