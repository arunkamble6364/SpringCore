package autowire;

public class Marks {
	Marks()
	{
		System.out.println("Marks Class Constructor");
		
	}
public void show()
{
	
 System.out.println("This is marks method show");	
}
}
