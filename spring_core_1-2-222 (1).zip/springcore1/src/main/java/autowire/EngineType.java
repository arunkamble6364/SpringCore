package autowire;

public class EngineType {
private String et;
  EngineType(String et)
  {
	  this.et=et;
  }

void showEngine()
{
  System.out.println("Engine " +et);	
}

}

