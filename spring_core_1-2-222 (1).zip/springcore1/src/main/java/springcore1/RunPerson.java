package springcore1;

import org.springframework.context.support.ClassPathXmlApplicationContext;
public class RunPerson {
public static void main(String s[])
{
	 ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationcontext.xml");	 
	 Person objP= (Person) context.getBean("p");
	 objP.showDetails();
}

}
