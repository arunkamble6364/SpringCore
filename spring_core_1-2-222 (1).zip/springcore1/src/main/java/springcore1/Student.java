package springcore1;

public class Student {
private String sname;
private int rollno;

public String getSname() {
	return sname;
}

public void setSname(String sname) {
	this.sname = sname;
}

public int getRollno() {
	return rollno;
}

public void setRollno(int rollno) {
	this.rollno = rollno;
}

public Student()
{
	System.out.println("default const");
}
public Student(String sname) {
	super();
	this.sname = sname;
	
}
public Student( int rollno) {
	super();
	this.rollno = rollno;
}

public Student(String sname, int rollno) {
	super();
	this.sname = sname;
	this.rollno = rollno;
}

public void show()
  {
	  System.out.println("Name of Student:-" +sname);
	  
  }
public void printBoth()
{
	  System.out.println("Name of Student:-" +sname);
	  System.out.println("RollNo of Student:-" +rollno);
}

}
