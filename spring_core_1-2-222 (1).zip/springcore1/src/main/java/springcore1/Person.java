package springcore1;
import java.util.Iterator;
import java.util.List;

public class Person {
private String pname;
private List<String> hobbies;

public Person(String pname, List<String> hobbies) {
	super();
	this.pname = pname;
	this.hobbies = hobbies;
}
 public void showDetails()
 {
	 System.out.println("name of person:- "+pname);
	 Iterator<String> itr =hobbies.iterator();
	 while(itr.hasNext())
		  System.out.println(itr.next());
 }
}
