package springcore1;
import org.springframework.context.support.ClassPathXmlApplicationContext;
public class RunStudent {
 public static void main(String s[])
 {
	 ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationcontext.xml");
	 // below code is using setter method
	 Student objs = (Student) context.getBean("studentbean");
	 objs.printBoth();
	 
	 // below code is for constructor 
	 /*Student obj2 = (Student) context.getBean("stdbeancons");
	 obj2.printBoth();*/
	 
 }
}
