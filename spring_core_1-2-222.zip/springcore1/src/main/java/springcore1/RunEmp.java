package springcore1;
import org.springframework.context.support.ClassPathXmlApplicationContext;
public class RunEmp {
public static void main(String s[])
{
	 ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationcontext.xml");	 
	 Employee objEmp= (Employee) context.getBean("empbean");
	 objEmp.showDetailEmp();
}

}
