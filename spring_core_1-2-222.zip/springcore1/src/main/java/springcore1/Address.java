package springcore1;

public class Address {
private String add1;
private String city;
private int phoneno;
public Address(String add1, String city, int phoneno) {
	super();
	this.add1 = add1;
	this.city = city;
	this.phoneno = phoneno;
}
void printAddress()
{
  System.out.println("Address Line 1:-"+add1);
  System.out.println("City:-"+city);
  System.out.println("Phone:-"+phoneno);
}
}
