package springcore1;

public class Employee {
private int eid;
private String ename;
private Address objAdd;

public Employee(int eid, String ename, Address objAdd) {
	super();
	this.eid = eid;
	this.ename = ename;
	this.objAdd = objAdd;
}

	void showDetailEmp()
	{
		System.out.println("Emp-id"+eid);
		System.out.println("Emp Name"+ename);
		objAdd.printAddress();
	}

}
